using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Blob;
using System.IO;
using Microsoft.Extensions.Configuration;
using System.Data.SqlClient;
using System.Data;

namespace smb.Controllers
{
    [Route("api/product")]
    public class ProductController:Controller
    {
        [HttpGet()]
        public JsonResult GetProducts()
        {
            string strConnectionString ="Server=tcp:bhaskarsnewserver.database.windows.net,1433;Initial Catalog=TESTDB;Persist Security Info=False;User ID=bhaskar;Password=Solivar@123;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;" ;
            SqlConnection sql = new SqlConnection(strConnectionString);
            // SqlCommand cmd = new SqlCommand("Select * from  DBO.PRODUCTS", sql);
            SqlDataAdapter dadapter=new SqlDataAdapter();
            dadapter.SelectCommand=new SqlCommand("Select * from  DBO.PRODUCTS",sql);
            DataSet dset=new DataSet();
            dadapter.Fill(dset);
            sql.Close();
            List<products> objList = new List<products>();
            foreach(DataRow dr in dset.Tables[0].Rows)
            {
                products objproducts = new products();
                objproducts.productId = Convert.ToInt32(dr["productId"]);
                objproducts.productName = Convert.ToString(dr["productName"]);
                objproducts.productCode = Convert.ToString(dr["productCode"]);
                objproducts.releaseDate = Convert.ToString(dr["releaseDate"]);
                objproducts.description = Convert.ToString(dr["description"]);
                objproducts.price = Convert.ToDecimal(dr["price"]);
                objproducts.starRating = Convert.ToDecimal(dr["starRating"]);
                objproducts.imageUrl = Convert.ToString(dr["imageUrl"]);
                objList.Add(objproducts);
            }

            return new JsonResult(objList) ;
        }
    }
}