public class products
{
public int productId;
public string productName;
public string productCode;
public string releaseDate;
public string description;
public decimal price;
public decimal starRating;
public string imageUrl;
}